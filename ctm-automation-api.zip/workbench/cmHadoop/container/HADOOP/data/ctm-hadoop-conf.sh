#!/bin/bash

ContainerDataDir=$(dirname "$0")
#delete old config file
rm -rf ${ContainerDataDir}/hadoop_conf.xml

# defaults
u=false
p=11000

usage() { echo "Usage: $0 [-h (oozie server host name)] [-p <oozie server port>] [-u <use ssl>] [-s <mapreduce streaming jar>"] 1>&2; exit 1; }

while getopts ":h:p:s:u" o; do
    case "${o}" in
        h)
            h=${OPTARG}
            ;;
        p)
            p=${OPTARG}
            ;;
        s)
            s=${OPTARG}
            ;;
        u)
            u=true
            ;;


        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

printf "\n"

echo "-- setting up the following configuration --"
echo "Oozie Server Host Name = ${h}"
echo "Oozie Server Port = ${p}"
echo "Mapreduce Streaming Jar = ${s}"
echo "Use ssl = ${u}"
echo "--------------------------------------------"

printf "\n"

echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>
<Hadoop>
        <Configuration>
                <StreamingJarPath>${s}</StreamingJarPath>
                <AgentPrincipal/>
                <AgentKeytabFilePath/>
                <TicketLifeTime>300</TicketLifeTime>
                <OozieHost>${h}</OozieHost>
                <OoziePort>${p}</OoziePort>
                <UseSsl>${u}</UseSsl>
        </Configuration>
</Hadoop>" >> ${ContainerDataDir}/hadoop_conf.xml

echo hadoop conf file:
cat ${ContainerDataDir}/hadoop_conf.xml
