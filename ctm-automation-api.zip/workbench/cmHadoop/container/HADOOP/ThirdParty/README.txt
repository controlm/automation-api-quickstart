To the extent that code covered by the Lesser General Public License (LGPL) is
included in this BMC product, in accordance with the LGPL, you may modify or
reverse engineer such LGPL-covered code, and notwithstanding anything to the contrary in your 
license agreement with BMC, you may modify and reverse engineer the portions of the BMC product
that combine or link with such LGPL-covered code solely as needed to permit the modification of 
the LGPL-covered code for your own use and debugging of such modifications of the LGPL-covered code.
BMC has and will have no obligation to support, warrant or provide indemnification for either the
modified portions of the BMC product or any modified version of the BMC product.