#!/bin/bash

JAVA_HOME_POSSIBLE_LOCATIONS='\
    /usr/java/jdk1.7* \
    /usr/java/jre1.7* \
    /usr/lib/jvm/j2sdk1.7-oracle \
    /usr/lib/jvm/j2sdk1.7-oracle/jre \
    /usr/lib/jvm/java-7-oracle* \
    /usr/lib/jvm/java-1.7.0-openjdk* \
    /usr/lib/jvm/java-7-openjdk* \
    /usr/java/jdk1.8* \
    /usr/java/jre1.8* \
    /usr/lib/jvm/j2sdk1.8-oracle \
    /usr/lib/jvm/j2sdk1.8-oracle/jre \
    /usr/lib/jvm/java-8-oracle* \
    /usr/lib/jvm/java-1.8.0-openjdk* \
    /usr/lib/jvm/java-8-openjdk* \
    /Library/Java/Home \
    /usr/java/default \
    /usr/lib/jvm/default-java \
    /usr/lib/jvm/java-openjdk \
    /usr/lib/jvm/jre-openjdk'


if [ -z "$JAVA_HOME" ]; then
  for java_location_option in $JAVA_HOME_POSSIBLE_LOCATIONS ; do
      for jre_path in `ls -rd $java_location_option 2>/dev/null`; do
        if [ -e $jre_path/bin/java ]; then
          export JAVA_HOME=$jre_path
          break 2
        fi
      done
  done
fi

echo using JAVA_HOME=$JAVA_HOME

current_dir=`pwd`
utl_path=`which $0`
utl_dir=`dirname $utl_path`

cd $utl_dir
SERVER_JAR=../control-m.services.server-1.0.0.jar

$JAVA_HOME/bin/java -Xmx512m -XX:+HeapDumpOnOutOfMemoryError -jar $SERVER_JAR -mode local $*

cd $current_dir
exit 0
